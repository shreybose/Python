Written by Sarayu Das and Shreya Bose

How to run prog3.py:
Step 1- Download the zipped file.
Step 2- Unzip the zipped file to desired location, which contains prog3.py, README.txt, input.txt.
Step 3- Open terminal.
Step 4- cd into the folder where the unzipped files are stored.
Step 5- Run the command python3 prog3.py input.txt

How to edit input.txt file:
Step 1- Open the file
Step 2- The first number is a, the second number is b, the third is prime. All separated by one space. Ex. 1 3 31
Step 3- Once changes to input.txt file are completed, save the file before running.
